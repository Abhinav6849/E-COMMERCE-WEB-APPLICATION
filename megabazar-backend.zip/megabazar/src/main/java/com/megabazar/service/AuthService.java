package com.megabazar.service;

import com.megabazar.dto.Dtos.*;
import com.megabazar.exception.ApiException;
import com.megabazar.model.User;
import com.megabazar.repo.UserRepository;
import com.megabazar.security.JwtService;
import java.time.Duration;
import java.time.Instant;
import org.springframework.http.HttpStatus;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class AuthService {
    private static final int MAX_FAILED_ATTEMPTS = 5;
    private static final Duration LOCK_TIME = Duration.ofMinutes(15);

    private final UserRepository users;
    private final PasswordEncoder encoder;
    private final JwtService jwt;

    public AuthService(UserRepository users, PasswordEncoder encoder, JwtService jwt) {
        this.users = users; this.encoder = encoder; this.jwt = jwt;
    }

    public static String normalizeEmail(String email) {
        return email == null ? "" : email.trim().toLowerCase();
    }

    public static void checkPasswordStrength(String password) {
        boolean letter = password.chars().anyMatch(Character::isLetter);
        boolean digit = password.chars().anyMatch(Character::isDigit);
        if (password.length() < 8 || !letter || !digit) {
            throw new ApiException(HttpStatus.BAD_REQUEST,
                    "Password must be at least 8 characters and contain a letter and a number");
        }
    }

    @Transactional
    public AuthResponse register(RegisterRequest r) {
        String email = normalizeEmail(r.email());
        if (users.existsByEmail(email)) {
            throw new ApiException(HttpStatus.CONFLICT, "An account with this email already exists. Please log in.");
        }
        checkPasswordStrength(r.password());
        User u = new User();
        u.setFullName(r.fullName().trim());
        u.setEmail(email);
        u.setPhone(r.phone() == null || r.phone().isBlank() ? null : r.phone());
        u.setPasswordHash(encoder.encode(r.password()));
        users.save(u);
        return new AuthResponse(jwt.generate(u), UserResponse.from(u));
    }

    /** noRollbackFor: the failed-attempt counter must be saved even though we throw an error. */
    @Transactional(noRollbackFor = ApiException.class)
    public AuthResponse login(LoginRequest r) {
        User u = users.findByEmail(normalizeEmail(r.email()))
                .orElseThrow(() -> new ApiException(HttpStatus.UNAUTHORIZED, "Invalid email or password"));
        if (!u.isEnabled()) {
            throw new ApiException(HttpStatus.FORBIDDEN, "This account has been disabled");
        }
        if (u.getLockedUntil() != null && u.getLockedUntil().isAfter(Instant.now())) {
            throw new ApiException(HttpStatus.TOO_MANY_REQUESTS,
                    "Too many failed attempts. Try again in 15 minutes or reset your password.");
        }
        if (!encoder.matches(r.password(), u.getPasswordHash())) {
            int attempts = u.getFailedAttempts() + 1;
            if (attempts >= MAX_FAILED_ATTEMPTS) {
                u.setLockedUntil(Instant.now().plus(LOCK_TIME));
                attempts = 0;
            }
            u.setFailedAttempts(attempts);
            users.save(u);
            throw new ApiException(HttpStatus.UNAUTHORIZED, "Invalid email or password");
        }
        u.setFailedAttempts(0);
        u.setLockedUntil(null);
        users.save(u);
        return new AuthResponse(jwt.generate(u), UserResponse.from(u));
    }

    @Transactional(readOnly = true)
    public UserResponse me(String email) {
        return UserResponse.from(find(email));
    }

    @Transactional
    public UserResponse updateProfile(String email, UpdateProfileRequest r) {
        User u = find(email);
        u.setFullName(r.fullName().trim());
        u.setPhone(r.phone() == null || r.phone().isBlank() ? null : r.phone());
        return UserResponse.from(users.save(u));
    }

    @Transactional
    public void changePassword(String email, ChangePasswordRequest r) {
        User u = find(email);
        if (!encoder.matches(r.currentPassword(), u.getPasswordHash())) {
            throw new ApiException(HttpStatus.BAD_REQUEST, "Current password is incorrect");
        }
        checkPasswordStrength(r.newPassword());
        u.setPasswordHash(encoder.encode(r.newPassword()));
        users.save(u);
    }

    private User find(String email) {
        return users.findByEmail(email).orElseThrow(() -> new ApiException(HttpStatus.UNAUTHORIZED, "Please log in again"));
    }
}
