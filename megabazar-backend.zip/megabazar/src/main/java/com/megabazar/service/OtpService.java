package com.megabazar.service;

import com.megabazar.exception.ApiException;
import com.megabazar.model.OtpToken;
import com.megabazar.model.User;
import com.megabazar.repo.OtpTokenRepository;
import com.megabazar.repo.UserRepository;
import java.security.SecureRandom;
import java.time.Instant;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/** OTP-based "forgot password": send OTP by email -> verify OTP -> set a new password. */
@Service
public class OtpService {
    private static final int MAX_ATTEMPTS = 5;
    private static final int RESEND_COOLDOWN_SECONDS = 60;

    private final UserRepository users;
    private final OtpTokenRepository tokens;
    private final PasswordEncoder encoder;
    private final EmailService emailService;
    private final int expiryMinutes;
    private final SecureRandom random = new SecureRandom();

    public OtpService(UserRepository users, OtpTokenRepository tokens, PasswordEncoder encoder,
                      EmailService emailService, @Value("${app.otp.expiry-minutes:10}") int expiryMinutes) {
        this.users = users; this.tokens = tokens; this.encoder = encoder;
        this.emailService = emailService; this.expiryMinutes = expiryMinutes;
    }

    /** Always behaves the same from the outside, so attackers cannot discover which emails are registered. */
    @Transactional
    public void sendOtp(String rawEmail) {
        String email = AuthService.normalizeEmail(rawEmail);
        Optional<User> user = users.findByEmail(email).filter(User::isEnabled);
        if (user.isEmpty()) return;

        Optional<OtpToken> last = tokens.findFirstByEmailOrderByCreatedAtDesc(email);
        if (last.isPresent() && last.get().getCreatedAt().plusSeconds(RESEND_COOLDOWN_SECONDS).isAfter(Instant.now())) {
            return; // an OTP was sent a few seconds ago
        }
        String otp = String.format("%06d", random.nextInt(1_000_000));
        tokens.deleteByEmail(email);
        tokens.save(new OtpToken(email, encoder.encode(otp), Instant.now().plusSeconds(expiryMinutes * 60L)));
        emailService.sendOtp(email, user.get().getFullName(), otp, expiryMinutes);
    }

    @Transactional(noRollbackFor = ApiException.class)
    public void verifyOtp(String rawEmail, String otp) {
        check(AuthService.normalizeEmail(rawEmail), otp);
    }

    @Transactional(noRollbackFor = ApiException.class)
    public void resetPassword(String rawEmail, String otp, String newPassword) {
        String email = AuthService.normalizeEmail(rawEmail);
        AuthService.checkPasswordStrength(newPassword);
        check(email, otp);
        User u = users.findByEmail(email).orElseThrow(this::invalid);
        u.setPasswordHash(encoder.encode(newPassword));
        u.setFailedAttempts(0);
        u.setLockedUntil(null);
        users.save(u);
        tokens.deleteByEmail(email); // an OTP can be used only once
    }

    private OtpToken check(String email, String otp) {
        OtpToken t = tokens.findFirstByEmailOrderByCreatedAtDesc(email).orElseThrow(this::invalid);
        if (t.getExpiresAt().isBefore(Instant.now())) {
            tokens.delete(t);
            throw new ApiException(HttpStatus.BAD_REQUEST, "This OTP has expired. Please request a new one.");
        }
        if (t.getAttempts() >= MAX_ATTEMPTS) {
            tokens.delete(t);
            throw new ApiException(HttpStatus.BAD_REQUEST, "Too many wrong attempts. Please request a new OTP.");
        }
        if (!encoder.matches(otp, t.getOtpHash())) {
            t.setAttempts(t.getAttempts() + 1);
            tokens.save(t);
            throw invalid();
        }
        return t;
    }

    private ApiException invalid() {
        return new ApiException(HttpStatus.BAD_REQUEST, "Invalid OTP");
    }
}
