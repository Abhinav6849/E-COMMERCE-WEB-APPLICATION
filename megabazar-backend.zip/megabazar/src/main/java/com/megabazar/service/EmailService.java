package com.megabazar.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.ObjectProvider;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.mail.MailException;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Service;

@Service
public class EmailService {
    private static final Logger log = LoggerFactory.getLogger(EmailService.class);

    private final ObjectProvider<JavaMailSender> mailSender;
    private final String from;
    private final boolean logOtp;
    private final String mailHost;

    public EmailService(ObjectProvider<JavaMailSender> mailSender,
                        @Value("${app.mail.from:}") String from,
                        @Value("${app.otp.log-to-console:false}") boolean logOtp,
                        @Value("${spring.mail.host:}") String mailHost) {
        this.mailSender = mailSender;
        this.from = from;
        this.logOtp = logOtp;
        this.mailHost = mailHost;
    }

    public void sendOtp(String to, String name, String otp, int minutes) {
        if (logOtp) {
            log.info("[DEV MODE] Password reset OTP for {} is {}", to, otp);
        }
        JavaMailSender sender = mailSender.getIfAvailable();
        if (sender == null || mailHost.isBlank()) {
            if (!logOtp) log.warn("Mail server is not configured - OTP email to {} was NOT sent", to);
            return;
        }
        try {
            SimpleMailMessage msg = new SimpleMailMessage();
            if (!from.isBlank()) msg.setFrom(from);
            msg.setTo(to);
            msg.setSubject("MegaBazaar password reset OTP");
            msg.setText("Hi " + name + ",\n\nYour MegaBazaar OTP is " + otp + ".\n"
                    + "It is valid for " + minutes + " minutes. Do not share it with anyone.\n\n"
                    + "If you did not request this, you can ignore this email.");
            sender.send(msg);
        } catch (MailException e) {
            log.error("Could not send OTP email to {}: {}", to, e.getMessage());
        }
    }
}
