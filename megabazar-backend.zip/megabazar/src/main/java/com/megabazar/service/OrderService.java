package com.megabazar.service;

import com.megabazar.dto.Dtos.*;
import com.megabazar.exception.ApiException;
import com.megabazar.model.*;
import com.megabazar.repo.OrderRepository;
import com.megabazar.repo.ProductRepository;
import com.megabazar.repo.UserRepository;
import java.math.BigDecimal;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class OrderService {
    private final OrderRepository orders;
    private final ProductRepository products;
    private final UserRepository users;

    public OrderService(OrderRepository orders, ProductRepository products, UserRepository users) {
        this.orders = orders; this.products = products; this.users = users;
    }

    /** Prices always come from the database - the browser's cart prices are never trusted. */
    @Transactional
    public OrderResponse place(String email, PlaceOrderRequest r) {
        User user = users.findByEmail(email)
                .orElseThrow(() -> new ApiException(HttpStatus.UNAUTHORIZED, "Please log in again"));

        Map<String, Integer> wanted = new TreeMap<>(); // sorted by name -> consistent lock order
        for (OrderItemRequest i : r.items()) wanted.merge(i.name().trim(), i.quantity(), Integer::sum);

        Order order = new Order();
        order.setUser(user);
        order.setShippingName(r.shippingName().trim());
        order.setShippingPhone(r.shippingPhone());
        order.setShippingAddress(r.shippingAddress().trim());

        BigDecimal total = BigDecimal.ZERO;
        for (Map.Entry<String, Integer> e : wanted.entrySet()) {
            String name = e.getKey();
            int qty = e.getValue();
            Product p = products.findActiveByNameForUpdate(name)
                    .orElseThrow(() -> new ApiException(HttpStatus.BAD_REQUEST, "\"" + name + "\" is no longer available"));
            if (p.getStock() < qty) {
                throw new ApiException(HttpStatus.CONFLICT, "Only " + p.getStock() + " left in stock for " + p.getName());
            }
            p.setStock(p.getStock() - qty);
            OrderItem item = new OrderItem();
            item.setProductId(p.getId());
            item.setProductName(p.getName());
            item.setImageUrl(p.getImageUrl());
            item.setUnitPrice(p.getPrice());
            item.setQuantity(qty);
            order.addItem(item);
            total = total.add(p.getPrice().multiply(BigDecimal.valueOf(qty)));
        }
        order.setTotalAmount(total);
        return OrderResponse.from(orders.save(order));
    }

    @Transactional(readOnly = true)
    public List<OrderResponse> myOrders(String email) {
        User user = users.findByEmail(email)
                .orElseThrow(() -> new ApiException(HttpStatus.UNAUTHORIZED, "Please log in again"));
        return orders.findByUserIdOrderByCreatedAtDesc(user.getId()).stream().map(OrderResponse::from).toList();
    }

    @Transactional(readOnly = true)
    public List<OrderResponse> allOrders() {
        return orders.findAllByOrderByCreatedAtDesc().stream().map(OrderResponse::from).toList();
    }

    @Transactional
    public OrderResponse updateStatus(Long id, OrderStatus status) {
        Order o = orders.findById(id).orElseThrow(() -> new ApiException(HttpStatus.NOT_FOUND, "Order not found"));
        if (o.getStatus() == OrderStatus.CANCELLED) {
            throw new ApiException(HttpStatus.BAD_REQUEST, "A cancelled order cannot be changed");
        }
        if (status == OrderStatus.CANCELLED) { // put the stock back
            for (OrderItem item : o.getItems()) {
                products.findById(item.getProductId()).ifPresent(p -> p.setStock(p.getStock() + item.getQuantity()));
            }
        }
        o.setStatus(status);
        return OrderResponse.from(o);
    }

    @Transactional(readOnly = true)
    public StatsResponse stats() {
        return new StatsResponse(users.count(), products.countByActiveTrue(), orders.count(),
                orders.revenueExcluding(OrderStatus.CANCELLED));
    }
}
