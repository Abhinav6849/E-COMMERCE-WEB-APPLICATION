package com.megabazar.service;

import com.megabazar.dto.Dtos.*;
import com.megabazar.exception.ApiException;
import com.megabazar.model.Product;
import com.megabazar.repo.ProductRepository;
import java.util.List;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class ProductService {
    private final ProductRepository products;

    public ProductService(ProductRepository products) { this.products = products; }

    @Transactional(readOnly = true)
    public PagedResult<ProductResponse> search(String q, String category, String sort, int page, int size) {
        int pageSize = Math.min(Math.max(size, 1), 100);
        String pattern = "%" + (q == null ? "" : q.trim().toLowerCase()) + "%";
        Sort order = switch (sort == null ? "" : sort) {
            case "price_asc" -> Sort.by("price");
            case "price_desc" -> Sort.by(Sort.Direction.DESC, "price");
            case "rating" -> Sort.by(Sort.Direction.DESC, "rating");
            default -> Sort.by("id");
        };
        Page<Product> result = products.search(category == null ? "" : category.trim(), pattern,
                PageRequest.of(Math.max(page, 0), pageSize, order));
        return new PagedResult<>(result.getContent().stream().map(ProductResponse::from).toList(),
                result.getNumber(), result.getTotalPages(), result.getTotalElements());
    }

    @Transactional(readOnly = true)
    public ProductResponse get(Long id) {
        Product p = products.findById(id).filter(Product::isActive).orElseThrow(this::notFound);
        return ProductResponse.from(p);
    }

    @Transactional(readOnly = true)
    public List<String> categories() { return products.findCategories(); }

    @Transactional(readOnly = true)
    public List<ProductResponse> listAllForAdmin() {
        return products.findAllByOrderByIdDesc().stream().map(ProductResponse::from).toList();
    }

    @Transactional
    public ProductResponse create(ProductRequest r) {
        Product p = new Product();
        apply(p, r);
        return ProductResponse.from(products.save(p));
    }

    @Transactional
    public ProductResponse update(Long id, ProductRequest r) {
        Product p = products.findById(id).orElseThrow(this::notFound);
        apply(p, r);
        return ProductResponse.from(products.save(p));
    }

    /** Soft delete: old orders keep their product history. */
    @Transactional
    public void deactivate(Long id) {
        Product p = products.findById(id).orElseThrow(this::notFound);
        p.setActive(false);
    }

    private void apply(Product p, ProductRequest r) {
        p.setName(r.name().trim());
        p.setCategory(r.category().trim());
        p.setDescription(r.description());
        p.setPrice(r.price());
        p.setMrp(r.mrp() != null ? r.mrp() : r.price());
        p.setImageUrl(r.imageUrl() == null || r.imageUrl().isBlank() ? null : r.imageUrl());
        p.setRating(r.rating() != null ? r.rating() : 0);
        p.setRatingCount(r.ratingCount() != null ? r.ratingCount() : 0);
        p.setStock(r.stock());
        p.setActive(r.active() == null || r.active());
    }

    private ApiException notFound() {
        return new ApiException(HttpStatus.NOT_FOUND, "Product not found");
    }
}
