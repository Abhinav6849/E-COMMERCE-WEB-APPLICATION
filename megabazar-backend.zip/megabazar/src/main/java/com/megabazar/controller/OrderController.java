package com.megabazar.controller;

import com.megabazar.dto.Dtos.*;
import com.megabazar.service.OrderService;
import jakarta.validation.Valid;
import java.security.Principal;
import java.util.List;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/orders")
public class OrderController {
    private final OrderService orders;

    public OrderController(OrderService orders) { this.orders = orders; }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public OrderResponse place(Principal p, @Valid @RequestBody PlaceOrderRequest r) {
        return orders.place(p.getName(), r);
    }

    @GetMapping
    public List<OrderResponse> mine(Principal p) { return orders.myOrders(p.getName()); }
}
