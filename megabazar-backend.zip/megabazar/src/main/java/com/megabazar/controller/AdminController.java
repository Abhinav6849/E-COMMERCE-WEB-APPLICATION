package com.megabazar.controller;

import com.megabazar.dto.Dtos.*;
import com.megabazar.repo.UserRepository;
import com.megabazar.service.OrderService;
import com.megabazar.service.ProductService;
import jakarta.validation.Valid;
import java.util.List;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

/** Everything under /api/admin requires the ADMIN role (see SecurityConfig). */
@RestController
@RequestMapping("/api/admin")
public class AdminController {
    private final ProductService products;
    private final OrderService orders;
    private final UserRepository users;

    public AdminController(ProductService products, OrderService orders, UserRepository users) {
        this.products = products; this.orders = orders; this.users = users;
    }

    @GetMapping("/stats")
    public StatsResponse stats() { return orders.stats(); }

    @GetMapping("/users")
    public List<UserResponse> users() {
        return users.findAllByOrderByCreatedAtDesc().stream().map(UserResponse::from).toList();
    }

    @GetMapping("/products")
    public List<ProductResponse> allProducts() { return products.listAllForAdmin(); }

    @PostMapping("/products")
    @ResponseStatus(HttpStatus.CREATED)
    public ProductResponse create(@Valid @RequestBody ProductRequest r) { return products.create(r); }

    @PutMapping("/products/{id}")
    public ProductResponse update(@PathVariable Long id, @Valid @RequestBody ProductRequest r) {
        return products.update(id, r);
    }

    @DeleteMapping("/products/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void delete(@PathVariable Long id) { products.deactivate(id); }

    @GetMapping("/orders")
    public List<OrderResponse> allOrders() { return orders.allOrders(); }

    @PatchMapping("/orders/{id}/status")
    public OrderResponse status(@PathVariable Long id, @Valid @RequestBody StatusRequest r) {
        return orders.updateStatus(id, r.status());
    }
}
