package com.megabazar.controller;

import com.megabazar.dto.Dtos.*;
import com.megabazar.service.AuthService;
import jakarta.validation.Valid;
import java.security.Principal;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/me")
public class UserController {
    private final AuthService auth;

    public UserController(AuthService auth) { this.auth = auth; }

    @GetMapping
    public UserResponse me(Principal p) { return auth.me(p.getName()); }

    @PutMapping
    public UserResponse update(Principal p, @Valid @RequestBody UpdateProfileRequest r) {
        return auth.updateProfile(p.getName(), r);
    }

    @PostMapping("/password")
    public MessageResponse changePassword(Principal p, @Valid @RequestBody ChangePasswordRequest r) {
        auth.changePassword(p.getName(), r);
        return new MessageResponse("Password changed");
    }
}
