package com.megabazar.controller;

import com.megabazar.dto.Dtos.*;
import com.megabazar.service.AuthService;
import com.megabazar.service.OtpService;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/auth")
public class AuthController {
    private final AuthService auth;
    private final OtpService otp;

    public AuthController(AuthService auth, OtpService otp) { this.auth = auth; this.otp = otp; }

    @PostMapping("/register")
    @ResponseStatus(HttpStatus.CREATED)
    public AuthResponse register(@Valid @RequestBody RegisterRequest r) { return auth.register(r); }

    @PostMapping("/login")
    public AuthResponse login(@Valid @RequestBody LoginRequest r) { return auth.login(r); }

    /** Step 1 of forgot password: email an OTP. */
    @PostMapping("/forgot-password")
    public MessageResponse forgot(@Valid @RequestBody EmailRequest r) {
        otp.sendOtp(r.email());
        return new MessageResponse("If an account exists for that email, an OTP has been sent. It is valid for 10 minutes.");
    }

    /** Step 2: check the OTP the user typed. */
    @PostMapping("/verify-otp")
    public MessageResponse verify(@Valid @RequestBody OtpVerifyRequest r) {
        otp.verifyOtp(r.email(), r.otp());
        return new MessageResponse("OTP verified");
    }

    /** Step 3: set the new password (OTP is checked again and then destroyed). */
    @PostMapping("/reset-password")
    public MessageResponse reset(@Valid @RequestBody ResetPasswordRequest r) {
        otp.resetPassword(r.email(), r.otp(), r.newPassword());
        return new MessageResponse("Password updated. You can now log in.");
    }
}
