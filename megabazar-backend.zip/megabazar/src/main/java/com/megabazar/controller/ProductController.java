package com.megabazar.controller;

import com.megabazar.dto.Dtos.*;
import com.megabazar.service.ProductService;
import java.util.List;
import org.springframework.web.bind.annotation.*;

/** Public, read-only product catalogue used by the storefront pages. */
@RestController
@RequestMapping("/api/products")
public class ProductController {
    private final ProductService products;

    public ProductController(ProductService products) { this.products = products; }

    @GetMapping
    public PagedResult<ProductResponse> list(@RequestParam(required = false) String q,
                                             @RequestParam(required = false) String category,
                                             @RequestParam(required = false) String sort,
                                             @RequestParam(defaultValue = "0") int page,
                                             @RequestParam(defaultValue = "20") int size) {
        return products.search(q, category, sort, page, size);
    }

    @GetMapping("/categories")
    public List<String> categories() { return products.categories(); }

    @GetMapping("/{id}")
    public ProductResponse get(@PathVariable Long id) { return products.get(id); }
}
