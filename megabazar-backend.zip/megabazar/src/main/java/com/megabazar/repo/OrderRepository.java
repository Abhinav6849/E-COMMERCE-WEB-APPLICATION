package com.megabazar.repo;

import com.megabazar.model.Order;
import com.megabazar.model.OrderStatus;
import java.math.BigDecimal;
import java.util.List;
import org.springframework.data.jpa.repository.EntityGraph;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

public interface OrderRepository extends JpaRepository<Order, Long> {

    @EntityGraph(attributePaths = {"user", "items"})
    List<Order> findByUserIdOrderByCreatedAtDesc(Long userId);

    @EntityGraph(attributePaths = {"user", "items"})
    List<Order> findAllByOrderByCreatedAtDesc();

    @Query("select coalesce(sum(o.totalAmount), 0) from PurchaseOrder o where o.status <> :excluded")
    BigDecimal revenueExcluding(@Param("excluded") OrderStatus excluded);
}
