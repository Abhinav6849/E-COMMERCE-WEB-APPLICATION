package com.megabazar.repo;

import com.megabazar.model.OtpToken;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;

public interface OtpTokenRepository extends JpaRepository<OtpToken, Long> {
    Optional<OtpToken> findFirstByEmailOrderByCreatedAtDesc(String email);
    void deleteByEmail(String email);
}
