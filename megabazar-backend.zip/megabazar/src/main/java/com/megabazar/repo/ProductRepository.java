package com.megabazar.repo;

import com.megabazar.model.Product;
import jakarta.persistence.LockModeType;
import java.util.List;
import java.util.Optional;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Lock;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

public interface ProductRepository extends JpaRepository<Product, Long> {

    /** category = "" means "all categories"; pattern is already lower-cased, e.g. "%phone%". */
    @Query("select p from Product p where p.active = true "
         + "and (:category = '' or lower(p.category) = lower(:category)) "
         + "and lower(p.name) like :pattern")
    Page<Product> search(@Param("category") String category, @Param("pattern") String pattern, Pageable pageable);

    @Query("select distinct p.category from Product p where p.active = true order by p.category")
    List<String> findCategories();

    @Lock(LockModeType.PESSIMISTIC_WRITE)
    @Query("select p from Product p where p.name = :name and p.active = true")
    Optional<Product> findActiveByNameForUpdate(@Param("name") String name);

    long countByActiveTrue();
    List<Product> findAllByOrderByIdDesc();
}
