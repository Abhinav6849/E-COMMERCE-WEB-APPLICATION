package com.megabazar.dto;

import com.megabazar.model.*;
import jakarta.validation.Valid;
import jakarta.validation.constraints.*;
import java.math.BigDecimal;
import java.time.Instant;
import java.util.List;

/** All request/response shapes of the REST API in one place. */
public final class Dtos {
    private Dtos() { }

    private static final String MOBILE = "^[6-9][0-9]{9}$";

    // ---------- auth ----------
    public record RegisterRequest(
            @NotBlank(message = "Full name is required") @Size(max = 100) String fullName,
            @NotBlank(message = "Email is required") @Email(message = "Enter a valid email") @Size(max = 150) String email,
            @Pattern(regexp = "^$|" + MOBILE, message = "Enter a valid 10-digit mobile number") String phone,
            @NotBlank(message = "Password is required") @Size(min = 8, max = 72, message = "Password must be 8-72 characters") String password) { }

    public record LoginRequest(@NotBlank(message = "Email is required") String email,
                               @NotBlank(message = "Password is required") String password) { }

    public record EmailRequest(@NotBlank(message = "Email is required") @Email(message = "Enter a valid email") String email) { }

    public record OtpVerifyRequest(
            @NotBlank @Email String email,
            @NotBlank @Pattern(regexp = "^[0-9]{6}$", message = "OTP must be 6 digits") String otp) { }

    public record ResetPasswordRequest(
            @NotBlank @Email String email,
            @NotBlank @Pattern(regexp = "^[0-9]{6}$", message = "OTP must be 6 digits") String otp,
            @NotBlank @Size(min = 8, max = 72, message = "Password must be 8-72 characters") String newPassword) { }

    public record ChangePasswordRequest(
            @NotBlank String currentPassword,
            @NotBlank @Size(min = 8, max = 72, message = "Password must be 8-72 characters") String newPassword) { }

    public record UpdateProfileRequest(
            @NotBlank(message = "Full name is required") @Size(max = 100) String fullName,
            @Pattern(regexp = "^$|" + MOBILE, message = "Enter a valid 10-digit mobile number") String phone) { }

    public record UserResponse(Long id, String fullName, String email, String phone, Role role,
                               boolean enabled, Instant createdAt) {
        public static UserResponse from(User u) {
            return new UserResponse(u.getId(), u.getFullName(), u.getEmail(), u.getPhone(), u.getRole(),
                    u.isEnabled(), u.getCreatedAt());
        }
    }

    public record AuthResponse(String token, UserResponse user) { }
    public record MessageResponse(String message) { }

    // ---------- products ----------
    public record ProductRequest(
            @NotBlank(message = "Product name is required") @Size(max = 200) String name,
            @NotBlank(message = "Category is required") @Size(max = 60) String category,
            @Size(max = 2000) String description,
            @NotNull(message = "Price is required") @DecimalMin(value = "0.01", message = "Price must be positive") BigDecimal price,
            @DecimalMin(value = "0.01", message = "MRP must be positive") BigDecimal mrp,
            @Pattern(regexp = "^(https?://\\S{1,990})?$", message = "Image must be a http(s) URL") String imageUrl,
            @DecimalMin("0") @DecimalMax("5") Double rating,
            @Min(0) Integer ratingCount,
            @NotNull(message = "Stock is required") @Min(value = 0, message = "Stock cannot be negative") Integer stock,
            Boolean active) { }

    public record ProductResponse(Long id, String name, String category, String description, BigDecimal price,
                                  BigDecimal mrp, String imageUrl, double rating, int ratingCount, int stock,
                                  boolean active) {
        public static ProductResponse from(Product p) {
            return new ProductResponse(p.getId(), p.getName(), p.getCategory(), p.getDescription(), p.getPrice(),
                    p.getMrp(), p.getImageUrl(), p.getRating(), p.getRatingCount(), p.getStock(), p.isActive());
        }
    }

    public record PagedResult<T>(List<T> items, int page, int totalPages, long totalItems) { }

    // ---------- orders ----------
    public record OrderItemRequest(@NotBlank String name,
                                   @Min(1) @Max(20) int quantity) { }

    public record PlaceOrderRequest(
            @NotEmpty(message = "Your cart is empty") @Size(max = 50) List<@Valid OrderItemRequest> items,
            @NotBlank(message = "Name is required") @Size(max = 100) String shippingName,
            @NotBlank(message = "Phone is required") @Pattern(regexp = MOBILE, message = "Enter a valid 10-digit mobile number") String shippingPhone,
            @NotBlank(message = "Address is required") @Size(max = 500) String shippingAddress) { }

    public record OrderItemResponse(Long productId, String productName, String imageUrl, BigDecimal unitPrice, int quantity) { }

    public record OrderResponse(Long id, Instant createdAt, OrderStatus status, BigDecimal totalAmount,
                                String paymentMethod, String shippingName, String shippingPhone,
                                String shippingAddress, String customerName, String customerEmail,
                                List<OrderItemResponse> items) {
        public static OrderResponse from(Order o) {
            List<OrderItemResponse> items = o.getItems().stream()
                    .map(i -> new OrderItemResponse(i.getProductId(), i.getProductName(), i.getImageUrl(),
                            i.getUnitPrice(), i.getQuantity()))
                    .toList();
            return new OrderResponse(o.getId(), o.getCreatedAt(), o.getStatus(), o.getTotalAmount(),
                    o.getPaymentMethod(), o.getShippingName(), o.getShippingPhone(), o.getShippingAddress(),
                    o.getUser().getFullName(), o.getUser().getEmail(), items);
        }
    }

    public record StatusRequest(@NotNull OrderStatus status) { }

    public record StatsResponse(long users, long products, long orders, BigDecimal revenue) { }
}
