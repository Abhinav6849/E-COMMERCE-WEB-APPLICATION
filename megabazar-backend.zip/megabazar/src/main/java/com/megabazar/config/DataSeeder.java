package com.megabazar.config;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.megabazar.model.Product;
import com.megabazar.model.Role;
import com.megabazar.model.User;
import com.megabazar.repo.ProductRepository;
import com.megabazar.repo.UserRepository;
import java.io.InputStream;
import java.math.BigDecimal;
import java.util.List;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.CommandLineRunner;
import org.springframework.core.io.ClassPathResource;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;

/** On first start: creates the admin account and loads the starter products from seed-products.json. */
@Component
public class DataSeeder implements CommandLineRunner {
    private static final Logger log = LoggerFactory.getLogger(DataSeeder.class);

    public record SeedProduct(String name, String category, BigDecimal price, BigDecimal mrp, String imageUrl,
                              double rating, int ratingCount, String description) { }

    private final UserRepository users;
    private final ProductRepository products;
    private final PasswordEncoder encoder;
    private final ObjectMapper mapper;
    private final String adminName;
    private final String adminEmail;
    private final String adminPassword;

    public DataSeeder(UserRepository users, ProductRepository products, PasswordEncoder encoder, ObjectMapper mapper,
                      @Value("${app.admin.name}") String adminName,
                      @Value("${app.admin.email}") String adminEmail,
                      @Value("${app.admin.password}") String adminPassword) {
        this.users = users; this.products = products; this.encoder = encoder; this.mapper = mapper;
        this.adminName = adminName; this.adminEmail = adminEmail.trim().toLowerCase(); this.adminPassword = adminPassword;
    }

    @Override
    public void run(String... args) throws Exception {
        if (!users.existsByEmail(adminEmail)) {
            User admin = new User();
            admin.setFullName(adminName);
            admin.setEmail(adminEmail);
            admin.setPasswordHash(encoder.encode(adminPassword));
            admin.setRole(Role.ADMIN);
            users.save(admin);
            log.info("Created admin account: {}", adminEmail);
        }
        if (products.count() == 0) {
            try (InputStream in = new ClassPathResource("seed-products.json").getInputStream()) {
                List<SeedProduct> seeds = mapper.readValue(in, new TypeReference<List<SeedProduct>>() { });
                for (SeedProduct s : seeds) {
                    Product p = new Product();
                    p.setName(s.name()); p.setCategory(s.category()); p.setDescription(s.description());
                    p.setPrice(s.price()); p.setMrp(s.mrp()); p.setImageUrl(s.imageUrl());
                    p.setRating(s.rating()); p.setRatingCount(s.ratingCount()); p.setStock(50);
                    products.save(p);
                }
                log.info("Loaded {} starter products", seeds.size());
            }
        }
    }
}
