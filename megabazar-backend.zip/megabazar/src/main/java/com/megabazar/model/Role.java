package com.megabazar.model;

public enum Role { CUSTOMER, ADMIN }
