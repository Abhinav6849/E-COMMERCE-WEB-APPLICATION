package com.megabazar.model;

import jakarta.persistence.*;
import java.math.BigDecimal;
import java.time.Instant;
import java.util.ArrayList;
import java.util.List;

@Entity(name = "PurchaseOrder")
@Table(name = "orders")
public class Order {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    private User user;
    @Column(nullable = false, precision = 12, scale = 2)
    private BigDecimal totalAmount = BigDecimal.ZERO;
    @Enumerated(EnumType.STRING) @Column(nullable = false)
    private OrderStatus status = OrderStatus.PLACED;
    @Column(nullable = false, length = 30)
    private String paymentMethod = "CASH_ON_DELIVERY";
    @Column(nullable = false, length = 100)
    private String shippingName;
    @Column(nullable = false, length = 15)
    private String shippingPhone;
    @Column(nullable = false, length = 500)
    private String shippingAddress;
    @Column(nullable = false, updatable = false)
    private Instant createdAt = Instant.now();
    @OneToMany(mappedBy = "order", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<OrderItem> items = new ArrayList<>();

    public void addItem(OrderItem item) { item.setOrder(this); items.add(item); }

    public Long getId() { return id; }
    public User getUser() { return user; }
    public void setUser(User v) { this.user = v; }
    public BigDecimal getTotalAmount() { return totalAmount; }
    public void setTotalAmount(BigDecimal v) { this.totalAmount = v; }
    public OrderStatus getStatus() { return status; }
    public void setStatus(OrderStatus v) { this.status = v; }
    public String getPaymentMethod() { return paymentMethod; }
    public String getShippingName() { return shippingName; }
    public void setShippingName(String v) { this.shippingName = v; }
    public String getShippingPhone() { return shippingPhone; }
    public void setShippingPhone(String v) { this.shippingPhone = v; }
    public String getShippingAddress() { return shippingAddress; }
    public void setShippingAddress(String v) { this.shippingAddress = v; }
    public Instant getCreatedAt() { return createdAt; }
    public List<OrderItem> getItems() { return items; }
}
