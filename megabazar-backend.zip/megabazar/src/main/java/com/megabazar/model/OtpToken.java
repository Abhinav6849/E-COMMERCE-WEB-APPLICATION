package com.megabazar.model;

import jakarta.persistence.*;
import java.time.Instant;

@Entity
@Table(name = "otp_tokens", indexes = @Index(columnList = "email"))
public class OtpToken {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @Column(nullable = false, length = 150)
    private String email;
    /** BCrypt hash of the 6-digit OTP. */
    @Column(nullable = false)
    private String otpHash;
    @Column(nullable = false)
    private Instant expiresAt;
    @Column(nullable = false, updatable = false)
    private Instant createdAt = Instant.now();
    private int attempts;

    protected OtpToken() { }
    public OtpToken(String email, String otpHash, Instant expiresAt) {
        this.email = email; this.otpHash = otpHash; this.expiresAt = expiresAt;
    }
    public Long getId() { return id; }
    public String getEmail() { return email; }
    public String getOtpHash() { return otpHash; }
    public Instant getExpiresAt() { return expiresAt; }
    public Instant getCreatedAt() { return createdAt; }
    public int getAttempts() { return attempts; }
    public void setAttempts(int v) { this.attempts = v; }
}
