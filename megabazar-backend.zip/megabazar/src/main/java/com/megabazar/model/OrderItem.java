package com.megabazar.model;

import jakarta.persistence.*;
import java.math.BigDecimal;

@Entity
@Table(name = "order_items")
public class OrderItem {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    private Order order;
    private Long productId;
    @Column(nullable = false, length = 200)
    private String productName;
    @Column(length = 1000)
    private String imageUrl;
    @Column(nullable = false, precision = 12, scale = 2)
    private BigDecimal unitPrice;
    private int quantity;

    public Long getId() { return id; }
    public Order getOrder() { return order; }
    public void setOrder(Order v) { this.order = v; }
    public Long getProductId() { return productId; }
    public void setProductId(Long v) { this.productId = v; }
    public String getProductName() { return productName; }
    public void setProductName(String v) { this.productName = v; }
    public String getImageUrl() { return imageUrl; }
    public void setImageUrl(String v) { this.imageUrl = v; }
    public BigDecimal getUnitPrice() { return unitPrice; }
    public void setUnitPrice(BigDecimal v) { this.unitPrice = v; }
    public int getQuantity() { return quantity; }
    public void setQuantity(int v) { this.quantity = v; }
}
