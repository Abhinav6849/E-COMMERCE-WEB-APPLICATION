/* MegaBazaar shared front-end helpers: API calls, login state, cart, header. */
const MB = (() => {
  const TOKEN = 'mb_token', USER = 'mb_user', CART = 'mb_cart';
  const registry = {};

  const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const money = n => '₹' + Number(n).toLocaleString('en-IN', { maximumFractionDigits: 2 });
  const fmtDate = iso => new Date(iso).toLocaleString('en-IN', { dateStyle: 'medium', timeStyle: 'short' });

  // ---------- login state ----------
  const token = () => localStorage.getItem(TOKEN);
  const user = () => { try { return JSON.parse(localStorage.getItem(USER)); } catch { return null; } };
  const setAuth = a => { localStorage.setItem(TOKEN, a.token); localStorage.setItem(USER, JSON.stringify(a.user)); };
  const clearAuth = () => { localStorage.removeItem(TOKEN); localStorage.removeItem(USER); };
  const logout = () => { clearAuth(); location.href = 'index.html'; };
  const currentPage = () => (location.pathname.split('/').pop() || 'index.html') + location.search;
  const safeNext = n => /^[a-z0-9-]+\.html(\?[^\s#]*)?$/i.test(n || '') ? n : null;
  const requireLogin = () => {
    if (token()) return true;
    location.replace('login.html?next=' + encodeURIComponent(currentPage()));
    return false;
  };

  // ---------- API ----------
  async function api(path, { method = 'GET', body, auth = true } = {}) {
    const headers = {};
    if (body !== undefined) headers['Content-Type'] = 'application/json';
    if (auth && token()) headers['Authorization'] = 'Bearer ' + token();
    let res;
    try {
      res = await fetch('/api' + path, { method, headers, body: body !== undefined ? JSON.stringify(body) : undefined });
    } catch (e) { throw new Error('Cannot reach the server. Please try again.'); }
    const text = await res.text();
    let data = null;
    if (text) { try { data = JSON.parse(text); } catch (e) { /* not json */ } }
    if (!res.ok) {
      if (res.status === 401 && token() && !path.startsWith('/auth/')) {
        clearAuth();
        location.href = 'login.html?next=' + encodeURIComponent(currentPage());
      }
      throw new Error((data && data.message) || 'Something went wrong (' + res.status + ')');
    }
    return data;
  }

  // ---------- messages / toast ----------
  function msg(el, text, ok) {
    el.textContent = text;
    el.className = 'text-sm rounded p-3 ' + (ok ? 'bg-green-50 text-green-700' : 'bg-red-50 text-red-700');
  }
  function toast(text) {
    const t = document.createElement('div');
    t.textContent = text;
    t.className = 'fixed bottom-6 left-1/2 -translate-x-1/2 bg-brand-dark text-white text-sm px-4 py-2 rounded shadow-lg z-[60]';
    document.body.appendChild(t);
    setTimeout(() => t.remove(), 2200);
  }

  // ---------- cart (kept in the browser; prices are re-checked by the server when ordering) ----------
  const getCart = () => { try { const c = JSON.parse(localStorage.getItem(CART)); return Array.isArray(c) ? c : []; } catch { return []; } };
  const cartCount = () => getCart().reduce((s, i) => s + i.quantity, 0);
  function updateBadge() { const b = document.getElementById('cart-badge'); if (b) b.textContent = cartCount(); }
  function setCart(c) { localStorage.setItem(CART, JSON.stringify(c)); updateBadge(); }
  function addToCart(name, price, image) {
    const c = getCart();
    const found = c.find(i => i.name === name);
    if (found) found.quantity = Math.min(found.quantity + 1, 20);
    else c.push({ name, price: Number(price), image: image || '', quantity: 1 });
    setCart(c);
    if (window.onCartChanged) window.onCartChanged(true); else toast(name + ' added to cart');
  }

  // ---------- header ----------
  function renderAuthArea() {
    const el = document.getElementById('auth-area');
    if (!el) return;
    const u = user();
    if (!token() || !u) {
      el.innerHTML = '<a href="login.html" class="bg-white text-brand-blue font-semibold px-4 sm:px-6 py-1.5 rounded-sm text-sm hover:bg-gray-100 transition shadow-sm">Login</a>' +
        '<a href="register.html" class="hidden sm:inline text-sm font-medium hover:text-brand-yellow transition ml-3">Sign Up</a>';
      return;
    }
    const first = esc((u.fullName || 'Account').split(' ')[0]);
    el.innerHTML = '<div class="relative group">' +
      '<button class="flex items-center gap-2 text-sm font-semibold hover:text-brand-yellow transition" tabindex="0"><i class="fa-regular fa-circle-user text-lg"></i><span>Hi, ' + first + '</span><i class="fa-solid fa-angle-down text-xs"></i></button>' +
      '<div class="absolute right-0 w-48 bg-white text-gray-800 shadow-xl rounded-sm py-2 hidden group-hover:block group-focus-within:block border border-gray-100 z-50">' +
      '<a href="dashboard.html" class="block px-4 py-2.5 text-sm hover:bg-brand-light"><i class="fa-solid fa-gauge text-brand-blue w-5"></i> My Dashboard</a>' +
      '<a href="dashboard.html#orders" class="block px-4 py-2.5 text-sm hover:bg-brand-light"><i class="fa-solid fa-box text-brand-blue w-5"></i> My Orders</a>' +
      '<button id="logout-btn" class="w-full text-left px-4 py-2.5 text-sm hover:bg-brand-light"><i class="fa-solid fa-right-from-bracket text-brand-blue w-5"></i> Logout</button>' +
      '</div></div>';
    document.getElementById('logout-btn').addEventListener('click', logout);
  }

  function wireSearch() {
    const go = v => { location.href = 'products.html?q=' + encodeURIComponent(v.trim()); };
    document.querySelectorAll('header input[type="text"]').forEach(inp => {
      inp.addEventListener('keydown', e => { if (e.key === 'Enter') go(inp.value); });
    });
    document.querySelectorAll('header .fa-magnifying-glass').forEach(icon => {
      const btn = icon.closest('button');
      if (btn) btn.addEventListener('click', () => go(btn.parentElement.querySelector('input').value));
    });
  }

  function renderHeader() {
    const el = document.getElementById('site-header');
    if (!el) return false;
    const q = new URLSearchParams(location.search).get('q') || '';
    el.innerHTML = '<header class="bg-brand-blue text-white sticky top-0 z-40 shadow-md">' +
      '<div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between gap-4">' +
      '<a href="index.html" class="flex flex-col items-start"><span class="text-2xl font-black italic tracking-wider text-brand-yellow">Mega<span class="text-white">Bazaar</span></span>' +
      '<span class="text-[10px] italic text-gray-200 -mt-1">Explore <span class="text-brand-yellow font-semibold">Plus</span></span></a>' +
      '<div class="flex-1 max-w-2xl relative hidden md:block"><input type="text" value="' + esc(q) + '" placeholder="Search for products, brands and more" class="w-full bg-white text-gray-800 rounded-sm py-2 pl-4 pr-10 text-sm focus:outline-none">' +
      '<button class="absolute right-0 top-0 h-full px-4 text-brand-blue"><i class="fa-solid fa-magnifying-glass"></i></button></div>' +
      '<div class="flex items-center gap-5"><div id="auth-area" class="flex items-center"></div>' +
      '<a href="checkout.html" class="flex items-center gap-2 font-medium hover:text-brand-yellow transition"><div class="relative"><i class="fa-solid fa-cart-shopping text-xl"></i>' +
      '<span id="cart-badge" class="absolute -top-2 -right-3 bg-brand-yellow text-brand-dark text-xs font-bold rounded-full h-5 w-5 flex items-center justify-center border-2 border-brand-blue">0</span></div>' +
      '<span class="hidden sm:inline font-semibold">Cart</span></a></div></div>' +
      '<div class="px-4 pb-3 md:hidden"><div class="relative w-full"><input type="text" value="' + esc(q) + '" placeholder="Search for products, brands and more" class="w-full bg-white text-gray-800 rounded-sm py-2 pl-4 pr-10 text-sm focus:outline-none">' +
      '<button class="absolute right-0 top-0 h-full px-4 text-brand-blue"><i class="fa-solid fa-magnifying-glass"></i></button></div></div></header>';
    return true;
  }

  // ---------- product card (same look as the original static cards) ----------
  function productCard(p) {
    registry[p.id] = p;
    const off = p.mrp > p.price ? Math.round((1 - p.price / p.mrp) * 100) : 0;
    const out = p.stock <= 0;
    return '<div class="group bg-white border border-gray-200 rounded-lg p-3 sm:p-4 hover:shadow-xl transition flex flex-col justify-between">' +
      '<a href="product.html?id=' + p.id + '"><div>' +
      '<div class="relative h-40 sm:h-48 overflow-hidden rounded flex items-center justify-center bg-gray-50 mb-3">' +
      '<img src="' + esc(p.imageUrl) + '" alt="' + esc(p.name) + '" class="object-contain h-full group-hover:scale-105 transition duration-300" onerror="this.style.visibility=\'hidden\'">' +
      (off ? '<span class="absolute top-2 left-2 bg-green-600 text-white text-[10px] font-bold px-1.5 py-0.5 rounded">' + off + '% OFF</span>' : '') + '</div>' +
      '<h3 class="font-medium text-sm text-gray-800 line-clamp-1 group-hover:text-brand-blue transition">' + esc(p.name) + '</h3>' +
      (p.ratingCount ? '<div class="flex items-center gap-1 mt-1"><span class="bg-green-700 text-white text-[10px] font-bold px-1.5 py-0.5 rounded">' + Number(p.rating).toFixed(1) + ' <i class="fa-solid fa-star text-[8px]"></i></span><span class="text-xs text-gray-400">(' + Number(p.ratingCount).toLocaleString('en-IN') + ')</span></div>' : '') +
      '</div></a><div class="mt-4"><div class="flex items-baseline gap-2"><span class="text-base sm:text-lg font-bold text-gray-900">' + money(p.price) + '</span>' +
      (off ? '<span class="text-xs text-gray-400 line-through">' + money(p.mrp) + '</span>' : '') + '</div>' +
      (out ? '<button disabled class="mt-2 w-full bg-gray-200 text-gray-500 font-semibold text-xs py-2 rounded">Out of stock</button>'
           : '<button data-add="' + p.id + '" class="mt-2 w-full bg-brand-yellow hover:bg-amber-400 text-brand-dark font-semibold text-xs py-2 rounded shadow-sm transition"><i class="fa-solid fa-cart-plus mr-1"></i> Add to Cart</button>') +
      '</div></div>';
  }

  document.addEventListener('click', e => {
    const b = e.target.closest('[data-add]');
    if (!b) return;
    const p = registry[b.dataset.add];
    if (p) addToCart(p.name, p.price, p.imageUrl);
  });

  function init() {
    renderHeader();
    renderAuthArea();
    wireSearch();
    updateBadge();
  }
  document.addEventListener('DOMContentLoaded', init);

  return { esc, money, fmtDate, token, user, setAuth, clearAuth, logout, safeNext, requireLogin, api, msg, toast,
           getCart, setCart, cartCount, updateBadge, addToCart, productCard };
})();
